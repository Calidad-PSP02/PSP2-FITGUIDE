/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package omr.uacm.sistemafitguide;

/**
 *
 * @author migue
 */
public class EstaturaFueraDeRangoException extends Exception {
    public EstaturaFueraDeRangoException(String mensaje) { super(mensaje); }
}
